exports.HmrState = function() {

};
